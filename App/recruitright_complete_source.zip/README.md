
# RecruitRight (Source)

React + Vite + Tailwind app for student-athlete recruiting.

## Dev
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Deploy (Netlify)
- Build command: `npm run build`
- Publish directory: `dist`
